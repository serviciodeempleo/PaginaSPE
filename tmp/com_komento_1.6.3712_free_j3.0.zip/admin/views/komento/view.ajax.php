<?php
/**
* @package		Komento
* @copyright	Copyright (C) 2012 Stack Ideas Private Limited. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Komento is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Restricted access');

require_once( KOMENTO_ADMIN_ROOT . DIRECTORY_SEPARATOR . 'views.php');

class KomentoViewKomento extends KomentoAdminView
{
	public function getVersion()
	{
		$ajax	= Komento::getAjax();

		$local		= Komento::komentoVersion();
		$remote		= Komento::getHelper( 'Version' )->getVersion();

		// Test build only since build will always be incremented regardless of version
		$localVersion	= explode( '.' , $local );
		$localBuild		= $localVersion[2];

		$remoteVersion	= explode( '.' , $remote );
		$build			= $remoteVersion[ 2 ];

		$html			= '<span class="version_outdated">' . JText::sprintf( 'COM_KOMENTO_VERSION_OUTDATED' , $local ) . '</span>';

		if( $localBuild >= $build )
		{
			$html		= '<span class="version_latest">' . JText::sprintf('COM_KOMENTO_VERSION_LATEST' , $local ) . '</span>';
		}

		$ajax->success( $html );
		$ajax->send();
	}
}
