window.Komento = abstractComponent();
